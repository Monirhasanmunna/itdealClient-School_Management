<div class="profile clearfix">
              <div class="profile_pic">
                <img style="width:60px;height:60px;border-radius:50%;" src="{{Auth::user()->avatar != 'user.png' ? asset(Auth::user()->avatar)  : asset('backend/image/user.png')}}" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2>John Doe</h2>
              </div>
            </div>