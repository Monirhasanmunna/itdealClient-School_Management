<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?>
      <h3>DASHBOARD</h3>
      <?php endif; ?>
      <ul class="nav side-menu">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard')): ?>
           <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard</a></li>  
        <?php endif; ?>
       

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management')): ?>
        <h3>User Management</h3>
        <li class="<?php echo e(Request::is('user_management/*') ? 'active' : ''); ?>"><a><i class="fa-solid fa-boxes-stacked"></i> User Management <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="<?php echo e(Request::is('user_management/*') ? 'display: block' : ''); ?>">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management.permissions')): ?>
            <li class="<?php echo e(Request::is('user_management/permission/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('userManagement.permission.index')); ?>">Permissions</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management.roles')): ?>
            <li class="<?php echo e(Request::is('user_management/role/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('userManagement.role.index')); ?>">Roles</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management.users')): ?>
            <li class="<?php echo e(Request::is('user_management/user/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('userManagement.user.index')); ?>">Users</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>

        <h3>ACTIVITIES</h3>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses')): ?>
        <li class="<?php echo e(Request::is('expense/*') ? 'active' : ''); ?>"><a><i class="fa-solid fa-calculator"></i> Expenses <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="<?php echo e(Request::is('expense/*') ? 'display: block' : ''); ?>">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.categories')): ?>
            <li class="<?php echo e(Request::is('expense/categories/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('expense.categories.index')); ?>">Categories</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.sub_categories')): ?>
            <li class="<?php echo e(Request::is('expense/sub_categories/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('expense.sub_categories.index')); ?>">Sub Categories</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('expenses.list')): ?>
            <li class="<?php echo e(Request::is('expense/expenses/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('expense.expenses.index')); ?>">Expenses List</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase')): ?>
        <li class="<?php echo e(Request::is('purchase/*') ? 'active' : ''); ?>"><a><i class="fa-solid fa-bucket"></i> Purchases <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="<?php echo e(Request::is('purchase/*') ? 'display: block' : ''); ?>">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.list')): ?>
            <li class="<?php echo e(Request::is('purchase/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('purchase.index')); ?>">Purchases List</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('purchase.return.list')): ?>
            <li><a href="index2.html">Return List</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales')): ?>
        <li><a><i class="fa-solid fa-bag-shopping"></i> Sales <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.quatations.list')): ?>
            <li><a href="index.html">Quotations List</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.invoices.list')): ?>
            <li><a href="index2.html">Invoices List</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sales.return.list')): ?>
            <li><a href="index3.html">Return List</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>


        <h3>Cashbook</h3>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products')): ?>
        <li class="<?php echo e(Request::is('cashbook/*') ? 'active' : ''); ?>"><a><i class="fa-solid fa-boxes-stacked"></i> Cashbook <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="<?php echo e(Request::is('cashbook/*') ? 'display: block' : ''); ?>">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cashbook.accounts')): ?>
            <li class="<?php echo e(Request::is('cashbook/accounts/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cashbook.balance.adjustment')): ?>
            <li class="<?php echo e(Request::is('cashbook/balance/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('balance.index')); ?>">Balance Adjustments</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cashbook.balance.transfer')): ?>
            <li class="<?php echo e(Request::is('cashbook/balance-transfer*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('balance-transfer.index')); ?>">Balance Transfer</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cashbook.transaction.history')): ?>
            <li class="<?php echo e(Request::is('cashbook/transaction*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('transaction.index')); ?>">Transaction History</a></li>
            <?php endif; ?>
            
          </ul>
        </li>
        <?php endif; ?>


        <h3>Inventory</h3>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('products')): ?>
        <li class="<?php echo e(Request::is(['product/*','/categories/*','/sub_categories/*']) ? 'active' : ''); ?>"><a><i class="fa-solid fa-boxes-stacked"></i> Products <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu" style="<?php echo e(Request::is('product/*') ? 'display: block' : ''); ?>">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.categories')): ?>
            <li class="<?php echo e(Request::is('/categories/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('product-category.index')); ?>">Categories</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.sub.categories')): ?>
            <li class="<?php echo e(Request::is('/sub_categories/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('product-sub-category.index')); ?>">Sub Categories</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.list')): ?>
            <li class="<?php echo e(Request::is('product/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('product.index')); ?>">Product List</a></li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.barcode')): ?>
            <li><a href="index3.html">Barcode</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory')): ?>
        <li><a><i class="fa-solid fa-warehouse"></i> Inventory <span class="fa fa-chevron-down"></span></a>
          <ul class="nav child_menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory.view_inventory')): ?>
            <li><a href="index.html">View Inventory</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inventory.adjustment')): ?>
            <li><a href="index2.html">Inventory Adjustment</a></li>
            <?php endif; ?>
          </ul>
        </li>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier')): ?>
        <h3>People</h3>
        <li class="<?php echo e(Request::is('suppliers/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('suppliers.index')); ?>"><i class="fa-solid fa-people-carry-box"></i> Suppliers</a></li>  
        <?php endif; ?>
        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('setup')): ?>
        <h3>Accounts</h3>
        <li class="<?php echo e(Request::is('setup/*') ? 'current-page' : ''); ?>"><a href="<?php echo e(route('setup.index')); ?>"><i class="fas fa-cogs"></i> Setup</a></li>  
        <?php endif; ?>

      </ul>
    </div>
  </div><?php /**PATH C:\laragon\www\laravel-inventory-management\resources\views/layouts/backend/sidebar-menu.blade.php ENDPATH**/ ?>