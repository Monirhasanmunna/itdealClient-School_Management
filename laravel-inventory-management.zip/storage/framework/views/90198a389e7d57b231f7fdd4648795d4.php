<footer>
    <div class="pull-right">
      Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
  </footer><?php /**PATH C:\laragon\www\laravel-inventory-management\resources\views/layouts/backend/footer-content.blade.php ENDPATH**/ ?>